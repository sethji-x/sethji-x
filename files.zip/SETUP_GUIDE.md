# Setup Guide — Graveyard Theme GitHub Profile README

## Files in this package
1. `README.md` — main profile README
2. `assets/banner.svg` — animated graveyard banner (used twice: top + bottom)
3. `snake.yml` — GitHub Action to generate the animated contribution snake (rename from `.github_workflows_snake.yml` when placing it, see below)

## Steps

### 1. Confirm your profile repo exists
Go to `github.com/sethji-x` → you need a repo literally named `sethji-x` (same as your username).
If it doesn't exist yet: click **New repository** → name it exactly `sethji-x` → check **"Add a README file"** → Create.
GitHub auto-detects this special repo and shows its README on your profile page.

### 2. Upload the files
In the `sethji-x/sethji-x` repo:
- Replace the existing `README.md` with the one from this package.
- Create a folder called `assets/` and upload `banner.svg` into it (path should end up as `assets/banner.svg`).
- Create a folder path `.github/workflows/` and upload the snake workflow file there, named `snake.yml` (path: `.github/workflows/snake.yml`).

You can do this either by dragging files in on the GitHub website (Add file → Upload files) or via git:

```bash
git clone https://github.com/sethji-x/sethji-x.git
cd sethji-x
mkdir -p assets .github/workflows
# copy banner.svg into assets/
# copy the snake workflow into .github/workflows/snake.yml
# copy README.md into the repo root
git add .
git commit -m "graveyard theme profile readme"
git push
```

### 3. Let the snake animation generate
Once `snake.yml` is pushed to `.github/workflows/`, go to the **Actions** tab of the repo → you should see "Generate Snake Animation" → click **Run workflow** manually the first time.
It creates a new branch called `output` with the animated SVG — this is what the README already links to, so once it runs once, the snake will show up automatically.

### 4. Double check the stats cards
The stats cards, streak stats, and top languages card in the README already point to username `sethji-x`. If your GitHub username ever changes, replace `sethji-x` everywhere in `README.md`.

### 5. View it live
Go to `github.com/sethji-x` — the README renders as your profile page. Give the stats services (github-readme-stats, streak-stats) a minute if they look blank on first load — they generate the image live.

## Notes
- No X/Twitter badge added since the handle wasn't confirmed — happy to add it later, just share the handle.
- All colors follow the graveyard palette: black `#0a0a0f`, blood red `#B90E0E`, deep blue `#1B3A6B`, fog grey `#8892b0`.
- The banner is a real animated SVG (moon pulse, drifting fog, flying bats, flickering candle) — GitHub renders SVG animations natively, no GIF needed.
